const {
    SlashCommandBuilder,
    EmbedBuilder,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
} = require('discord.js');

const data = new SlashCommandBuilder()
    .setName('avatar')
    .setDescription("Afficher l'avatar d'un membre du serveur")
    .addUserOption((opt) =>
        opt
            .setName('user')
            .setDescription("Membre dont tu veux voir l'avatar")
            .setRequired(true)
);

async function execute(interaction) {
    const user = interaction.options.getUser('user', true);

    const avatarURL = user.displayAvatarURL({
        extension: 'png',
        size: 4096,
        forceStatic: false,

    });

    const embed = new EmbedBuilder()
        .setTitle(`🖼️ Avatar de ${user.displayName || user.username}`)
        .setImage(avatarURL)
        .setColor(0x5865f2);

    const button = new ButtonBuilder()
        .setLabel("Ouvrir l'avatar")
        .setStyle(ButtonStyle.Link)
        .setURL(avatarURL);

    const row = new ActionRowBuilder().addComponents(button);

    await interaction.reply({
        embeds: [embed],
        components: [row],

    });
}

module.exports = { data, execute };