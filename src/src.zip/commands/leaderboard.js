const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { formatDuration } = require("../utils/xp");

const data = new SlashCommandBuilder()
  .setName("leaderboard")
  .setDescription("Voir le classement.")
  .addStringOption((opt) =>
    opt
      .setName("type")
      .setDescription("Type de classement")
      .setRequired(false)
      .addChoices(
        { name: "XP", value: "xp" },
        { name: "Messages", value: "messages" },
        { name: "Vocal (temps)", value: "voice_seconds" }
      )
  )
  .addIntegerOption((opt) => opt.setName("page").setDescription("Page (1 = top)").setRequired(false));

async function execute(interaction, ctx) {
  const type = interaction.options.getString("type") || "xp";
  const page = Math.max(1, interaction.options.getInteger("page") || 1);

  const pageSize = 10;
  const offset = (page - 1) * pageSize;

  const rows = ctx.db.getLeaderboard(interaction.guild.id, type, pageSize, offset);
  if (!rows.length) {
    await interaction.reply({ content: "Aucune donnée pour cette page.", ephemeral: true });
    return;
  }

  const lines = await Promise.all(
    rows.map(async (r, i) => {
      const rank = offset + i + 1;
      const member = await interaction.guild.members.fetch({ user: r.user_id, force: true }).catch(() => null);
      console.log(member?.nickname, member?.displayName, member?.user?.username);
      const name = member ? member.displayName : `<@${r.user_id}>`;

      if (type === "messages") return `**#${rank}** ${name} — **${r.messages}** messages (XP: ${r.xp})`;
      if (type === "voice_seconds")
        return `**#${rank}** ${name} — **${formatDuration(r.voice_seconds)}** (XP: ${r.xp})`;

      return `**#${rank}** ${name} — **${r.xp}** XP (msg: ${r.messages}, vocal: ${formatDuration(r.voice_seconds)})`;
    })
  );

  const embed = new EmbedBuilder()
    .setTitle(`🏆 Leaderboard (${type}) — page ${page}`)
    .setDescription(lines.join("\n"));

  await interaction.reply({ embeds: [embed] });
}

module.exports = { data, execute };